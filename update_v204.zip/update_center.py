"""Owner-approved ZIP update staging; no hidden downloads or remote code execution.

Applies allowlisted Python source files only after a Telegram owner confirms their hash.
Current Python process needs an explicit restart afterward (Windows CMD or cloud supervisor).
"""
from __future__ import annotations

import ast
import hashlib
import io
import os
import re
import shutil
import sqlite3
import tempfile
import threading
import zipfile
from datetime import datetime
from pathlib import Path

VERSION = '2.0.4'
MAX_ARCHIVE_BYTES = 4 * 1024 * 1024
MAX_EXTRACTED_BYTES = 8 * 1024 * 1024
MAX_FILES = 35
ALLOWED_PY = frozenset('''bot.py ai_brain.py ai_router.py assistant_features.py
proactive_features.py contextual_advice.py daily_planner.py focus_engine.py
focus_ui.py goals_engine.py offline_ready.py task_numbers.py backup_db.py
update_center.py update_ui.py'''.split())
APPLY_LOCK = threading.Lock()


class UpdateError(ValueError):
    pass


def _root(base):
    return Path(base).resolve()


def digest(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _check_file_name(name: str) -> bool:
    # Flat Python modules only; documentation and tests are permitted but never installed.
    if name in ALLOWED_PY:
        return True
    if re.fullmatch(r'tests_v[0-9]+_offline\.py', name):
        return False
    if name == 'requirements.txt' or re.fullmatch(r'(?:README|CHANGELOG)_[A-Za-z0-9_]+\.txt', name):
        return False
    raise UpdateError(f'Запрещённый или неизвестный файл в архиве: {name[:80]}')


def inspect_zip(content: bytes) -> list[str]:
    if len(content) > MAX_ARCHIVE_BYTES:
        raise UpdateError('ZIP превышает допустимые 4 МБ.')
    result = []
    total = 0
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            entries = archive.infolist()
            if not entries or len(entries) > MAX_FILES:
                raise UpdateError('ZIP пустой или содержит слишком много файлов.')
            for info in entries:
                if info.is_dir():
                    raise UpdateError('Архив должен содержать только файлы в корне.')
                python_source = _check_file_name(info.filename)
                # POSIX symbolic link marker in external_attr
                filemode = (info.external_attr >> 16) & 0o170000
                if filemode == 0o120000:
                    raise UpdateError('Символические ссылки в обновлении запрещены.')
                if info.filename in result:
                    raise UpdateError('Повторяющееся имя файла в архиве.')
                total += info.file_size
                if total > MAX_EXTRACTED_BYTES:
                    raise UpdateError('Распакованные файлы слишком большие.')
                data = archive.read(info)
                if len(data) != info.file_size:
                    raise UpdateError('Ошибка проверки размера файла.')
                if python_source:
                    try:
                        source = data.decode('utf-8-sig')
                        ast.parse(source, filename=info.filename)
                    except (UnicodeError, SyntaxError) as exc:
                        raise UpdateError(f'Некорректный Python-файл {info.filename}: {exc}') from exc
                    result.append(info.filename)
    except (zipfile.BadZipFile, RuntimeError, OSError) as exc:
        raise UpdateError('ZIP повреждён или не читается.') from exc
    if not result:
        raise UpdateError("В ZIP нет подходящих файлов обновления бота.")
    return sorted(result)


def snapshot(base, db_path, label='manual') -> Path:
    """Consistent SQLite backup and safe source snapshot; never store tokens or .env."""
    root = _root(base)
    backups = root / 'backups'
    backups.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    folder = backups / f'bot_{label}_{stamp}'
    folder.mkdir(parents=False, exist_ok=False)
    try:
        for name in ALLOWED_PY:
            src = root / name
            if src.is_file():
                shutil.copy2(src, folder / name)
        db_file = Path(db_path)
        if not db_file.is_absolute():
            db_file = root / db_file
        if db_file.is_file():
            with sqlite3.connect(str(db_file)) as db, sqlite3.connect(str(folder/'assistant.db')) as out:
                db.backup(out)
        (folder/'README_RESTORE.txt').write_text(
            'Копия исходного кода и SQLite перед обновлением. Не отправляй её другим людям.\n'
            'Не заменяй работающую базу без отдельного резервного копирования.\n',
            encoding='utf-8')
        return folder
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise


def apply_update(base, db_path, content: bytes, *, expected_sha256: str):
    """Atomically replace permitted .py files; on a copy error restore former code.

    Does not restart Python, update dependencies or modify the active database.
    """
    if not re.fullmatch(r'[0-9a-f]{64}', expected_sha256) or digest(content) != expected_sha256:
        raise UpdateError('Контрольная сумма ZIP изменилась. Установка отменена.')
    files = inspect_zip(content)
    root = _root(base)
    with APPLY_LOCK:
        backup = snapshot(root, db_path, label='before_update')
        saved = {}
        installed = []
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                for name in files:
                    target = root / name
                    saved[name] = target.read_bytes() if target.is_file() else None
                    data = archive.read(name)
                    with tempfile.NamedTemporaryFile('wb', dir=root, prefix='.staged_', suffix='.tmp', delete=False) as tmp:
                        tmp.write(data)
                        staged = Path(tmp.name)
                    try:
                        os.replace(staged, target)
                        installed.append(name)
                    finally:
                        staged.unlink(missing_ok=True)
            return files, backup
        except Exception:
            # Restore every file already replaced, without touching SQLite.
            for name in reversed(installed):
                target = root / name
                old = saved[name]
                if old is None:
                    target.unlink(missing_ok=True)
                else:
                    with tempfile.NamedTemporaryFile('wb', dir=root, prefix='.restore_', suffix='.tmp', delete=False) as tmp:
                        tmp.write(old)
                        path = Path(tmp.name)
                    os.replace(path, target)
            raise

# Daily release discovery (no silent code installation). All download destinations
# are fixed by the owner outside Telegram, not supplied by an incoming message.
import ipaddress
import json
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

MANIFEST_ENV = 'ASSISTANT_UPDATE_MANIFEST_URL'
MAX_MANIFEST_BYTES = 64 * 1024
RELEASE_TIMEOUT_SECONDS = 12


def _trusted_https(url: str, *, same_host: str | None = None) -> str:
    if not isinstance(url, str) or len(url) > 1800 or any(ch.isspace() for ch in url):
        raise UpdateError('Некорректный адрес обновлений.')
    try:
        parsed = urlsplit(url)
        host = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise UpdateError('Некорректный HTTPS-адрес.') from exc
    if parsed.scheme != 'https' or not host or parsed.username or parsed.password or parsed.fragment or (port not in (None, 443)):
        raise UpdateError('Обновления доступны только по обычному HTTPS-адресу без пароля.')
    host = host.lower()
    if host in ('localhost', 'localhost.localdomain') or host.endswith(('.local', '.internal')):
        raise UpdateError('Локальные адреса для загрузки запрещены.')
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        if not ip.is_global:
            raise UpdateError('Внутренние IP-адреса запрещены.')
    if same_host is not None and host != same_host:
        raise UpdateError('ZIP должен находиться на том же доверенном HTTPS-хосте, что и manifest.')
    return host


def configured_manifest_url() -> str | None:
    url = os.getenv(MANIFEST_ENV, '').strip()
    if not url:
        return None
    _trusted_https(url)
    return url


def version_tuple(v: str) -> tuple[int, int, int]:
    if not isinstance(v, str) or not re.fullmatch(r'[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}', v):
        raise UpdateError('Версия должна иметь вид 2.1.0.')
    return tuple(int(x) for x in v.split('.'))


def parse_release(data: bytes, manifest_url: str) -> dict:
    manifest_host = _trusted_https(manifest_url)
    if len(data) > MAX_MANIFEST_BYTES:
        raise UpdateError('Манифест обновления слишком большой.')
    try:
        document = json.loads(data.decode('utf-8'))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise UpdateError('Недопустимый JSON манифеста.') from exc
    if not isinstance(document, dict):
        raise UpdateError('Манифест должен быть JSON-объектом.')
    version = document.get('version')
    version_tuple(version)
    zip_url = document.get('zip_url')
    _trusted_https(zip_url, same_host=manifest_host)
    sha = document.get('sha256')
    if not isinstance(sha, str) or not re.fullmatch('[a-f0-9]{64}', sha):
        raise UpdateError('Нужна полная SHA-256 ZIP-файла.')
    notes = document.get('notes', '')
    if not isinstance(notes, str) or len(notes) > 1000:
        raise UpdateError('Недопустимое описание обновления.')
    return {'version': version, 'zip_url': zip_url, 'sha256': sha, 'notes': notes.strip()}


def _fetch_bytes(url: str, limit: int, *, expected_host: str | None = None) -> bytes:
    import httpx
    _trusted_https(url, same_host=expected_host)
    # Refuse redirects: prevents silently switching to a different host.
    with httpx.Client(timeout=RELEASE_TIMEOUT_SECONDS, follow_redirects=False) as client:
        with client.stream('GET', url) as response:
            if response.status_code != 200:
                raise UpdateError(f'Сервер обновлений вернул HTTP {response.status_code}.')
            size = 0
            chunks = []
            for chunk in response.iter_bytes():
                size += len(chunk)
                if size > limit:
                    raise UpdateError('Скачанный файл превышает допустимый размер.')
                chunks.append(chunk)
    return b''.join(chunks)


def fetch_release(manifest_url: str) -> dict:
    raw = _fetch_bytes(manifest_url, MAX_MANIFEST_BYTES)
    return parse_release(raw, manifest_url)


def fetch_release_zip(release: dict, manifest_url: str) -> bytes:
    host = _trusted_https(manifest_url)
    data = _fetch_bytes(release['zip_url'], MAX_ARCHIVE_BYTES, expected_host=host)
    if digest(data) != release['sha256']:
        raise UpdateError('SHA-256 скачанного ZIP не совпадает с опубликованной. Обновление отклонено.')
    inspect_zip(data)
    return data


def migrate_release_checks(db) -> None:
    db.execute('''CREATE TABLE IF NOT EXISTS update_check_settings (
        user_id INTEGER PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        last_check_date TEXT NOT NULL DEFAULT '',
        notified_version TEXT NOT NULL DEFAULT ''
    )''')


def release_settings(db, owner_id: int) -> dict:
    migrate_release_checks(db)
    db.execute('INSERT OR IGNORE INTO update_check_settings(user_id) VALUES (?)', (owner_id,))
    row = db.execute('SELECT enabled,last_check_date,notified_version FROM update_check_settings WHERE user_id=?', (owner_id,)).fetchone()
    return {'enabled': bool(row[0]), 'last_check_date': row[1], 'notified_version': row[2]}


def release_set_enabled(db, owner_id: int, enabled: bool) -> None:
    release_settings(db, owner_id)
    db.execute('UPDATE update_check_settings SET enabled=? WHERE user_id=?', (int(bool(enabled)),owner_id))


def release_mark_checked(db, owner_id: int, date_str: str) -> None:
    release_settings(db,owner_id)
    db.execute('UPDATE update_check_settings SET last_check_date=? WHERE user_id=?', (date_str,owner_id))


def release_mark_notified(db, owner_id: int, version: str) -> None:
    release_settings(db,owner_id)
    db.execute('UPDATE update_check_settings SET notified_version=? WHERE user_id=?', (version,owner_id))


def release_is_newer(release: dict) -> bool:
    return version_tuple(release['version']) > version_tuple(VERSION)
