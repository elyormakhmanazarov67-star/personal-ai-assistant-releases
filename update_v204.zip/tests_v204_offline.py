"""Offline checks for owner-approved automatic release discovery v2.0.4."""
import asyncio
import io
import json
import sqlite3
import tempfile
import unittest
import zipfile
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, AsyncMock
from zoneinfo import ZoneInfo

import tests_v16_offline  # Telegram stub classes used by old tests
import bot
import update_center as uc
import update_ui as ui

MANIFEST = 'https://raw.githubusercontent.com/demo-owner/bot/main/release.json'
ZIP_URL = 'https://raw.githubusercontent.com/demo-owner/bot/main/update.zip'
NEW_ZIP = io.BytesIO()
with zipfile.ZipFile(NEW_ZIP, 'w') as zip_file:
    zip_file.writestr('bot.py', 'HELLO = True\n')
NEW_ZIP = NEW_ZIP.getvalue()


def release(version='2.0.5', **overrides):
    doc = {'version':version, 'zip_url':ZIP_URL, 'sha256':uc.digest(NEW_ZIP), 'notes':'Новый режим'}
    doc.update(overrides)
    return doc


class ReleaseValidation(unittest.TestCase):
    def test_version_sort_not_lexicographic(self):
        self.assertLess(uc.version_tuple('2.0.9'),uc.version_tuple('2.0.10'))
        self.assertTrue(uc.release_is_newer(release('2.0.5')))
        self.assertFalse(uc.release_is_newer(release('2.0.4')))
        self.assertFalse(uc.release_is_newer(release('2.0.3')))

    def test_empty_and_invalid_configuration(self):
        with patch.dict('os.environ',{},clear=True):
            self.assertIsNone(uc.configured_manifest_url())
        for bad in ('http://example.com/a.json','https://localhost/a.json',
                    'https://127.0.0.1/a','https://user:pass@example.com/a',
                    'https://example.com:8080/a','file:///tmp/a'):
            with self.subTest(bad=bad):
                with patch.dict('os.environ',{uc.MANIFEST_ENV:bad}):
                    with self.assertRaises(uc.UpdateError):uc.configured_manifest_url()

    def test_manifest_data_rejects_untrusted_and_corruption(self):
        self.assertEqual(uc.parse_release(json.dumps(release()).encode(),MANIFEST)['version'],'2.0.5')
        for obj in (release(version='2.0.5-alpha'),
                    release(zip_url='https://evil.test/patch.zip'),
                    release(zip_url='http://raw.githubusercontent.com/a.zip'),
                    release(sha256='not-real'), release(notes='x'*2000)):
            with self.subTest(obj=obj):
                with self.assertRaises(uc.UpdateError): uc.parse_release(json.dumps(obj).encode(),MANIFEST)
        with self.assertRaises(uc.UpdateError):uc.parse_release(b'not-json',MANIFEST)
        with self.assertRaises(uc.UpdateError):uc.parse_release(b' '*65537,MANIFEST)

    def test_release_zip_checks_hash_before_code_parsing(self):
        r=release()
        with patch.object(uc,'_fetch_bytes',return_value=NEW_ZIP):
            self.assertEqual(uc.fetch_release_zip(r,MANIFEST),NEW_ZIP)
        with patch.object(uc,'_fetch_bytes',return_value=b'broken zip'):
            with self.assertRaises(uc.UpdateError):uc.fetch_release_zip(r,MANIFEST)

    def test_daily_state_dedup_and_opt_out(self):
        with sqlite3.connect(':memory:') as db:
            first=uc.release_settings(db,777)
            self.assertTrue(first['enabled'])
            uc.release_mark_checked(db,777,'2026-10-10')
            uc.release_mark_notified(db,777,'2.0.5')
            uc.release_set_enabled(db,777,False)
            self.assertEqual(uc.release_settings(db,777),{'enabled':False,'last_check_date':'2026-10-10','notified_version':'2.0.5'})


class ScheduledCheck(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.old_db=bot.DB_PATH;self.old_now=bot.now;self.old_owner=bot.OWNER_ID
        bot.DB_PATH=str(Path(self.temp.name)/'assistant.db')
        bot.OWNER_ID=123
        bot.now=lambda:datetime(2026,10,10,11,0,tzinfo=ZoneInfo('Asia/Tashkent'))
        bot.init_db()
        self.ctx=SimpleNamespace(bot=SimpleNamespace(send_message=AsyncMock()))

    async def asyncTearDown(self):
        bot.DB_PATH=self.old_db;bot.now=self.old_now;bot.OWNER_ID=self.old_owner
        self.temp.cleanup()

    async def test_daily_check_once_even_after_restart(self):
        with patch.object(ui,'configured_manifest_url',return_value=MANIFEST),patch.object(ui,'fetch_release',return_value=release()):
            await ui.scheduled_release_check(self.ctx)
            await ui.scheduled_release_check(self.ctx)
            self.assertEqual(self.ctx.bot.send_message.await_count,1)
            with bot.connect() as db:
                self.assertEqual(uc.release_settings(db,123)['last_check_date'],'2026-10-10')
                self.assertEqual(uc.release_settings(db,123)['notified_version'],'2.0.5')
            bot.init_db()  # Simulated process restart
            await ui.scheduled_release_check(self.ctx)
            self.assertEqual(self.ctx.bot.send_message.await_count,1)

    async def test_quiet_hours_and_disabled(self):
        bot.now=lambda:datetime(2026,10,10,2,0,tzinfo=ZoneInfo('Asia/Tashkent'))
        with patch.object(ui,'configured_manifest_url',return_value=MANIFEST),patch.object(ui,'fetch_release',return_value=release()) as fetch:
            await ui.scheduled_release_check(self.ctx)
            fetch.assert_not_called()
            bot.now=lambda:datetime(2026,10,10,11,0,tzinfo=ZoneInfo('Asia/Tashkent'))
            with bot.connect() as db:uc.release_set_enabled(db,123,False)
            await ui.scheduled_release_check(self.ctx)
            fetch.assert_not_called()

    async def test_failed_check_does_not_notify(self):
        with patch.object(ui,'configured_manifest_url',return_value=MANIFEST),patch.object(ui,'fetch_release',side_effect=uc.UpdateError('HTTP 500')):
            await ui.scheduled_release_check(self.ctx)
            self.ctx.bot.send_message.assert_not_awaited()

    async def test_no_available_manifest_is_silent(self):
        with patch.object(ui,'configured_manifest_url',return_value=None),patch.object(ui,'fetch_release') as fetch:
            await ui.scheduled_release_check(self.ctx)
            fetch.assert_not_called()

    async def test_no_spam_on_new_day_same_release(self):
        with patch.object(ui,'configured_manifest_url',return_value=MANIFEST),patch.object(ui,'fetch_release',return_value=release()):
            await ui.scheduled_release_check(self.ctx)
            bot.now=lambda:datetime(2026,10,11,12,0,tzinfo=ZoneInfo('Asia/Tashkent'))
            await ui.scheduled_release_check(self.ctx)
            self.assertEqual(self.ctx.bot.send_message.await_count,1)


if __name__=='__main__':unittest.main()
