"""Telegram owner-only user interface for backup and approved local Python updates."""
import time
import asyncio
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M
from update_center import (
    VERSION, UpdateError, inspect_zip, digest, snapshot, apply_update, MAX_ARCHIVE_BYTES,
    configured_manifest_url, fetch_release, fetch_release_zip, release_is_newer,
    release_settings, release_set_enabled, release_mark_checked, release_mark_notified,
)


def update_keyboard():
    return M([
        [B('ℹ️ Версия и состояние', callback_data='up:status')],
        [B('🗃 Создать резервную копию', callback_data='up:backup')],
        [B('📦 Загрузить ZIP-обновление', callback_data='up:upload')],
        [B('🔎 Проверить новые версии', callback_data='up:check')],
        [B('✅ Включить ежедневную проверку', callback_data='up:auto_on')],
        [B('🔕 Выключить ежедневную проверку', callback_data='up:auto_off')],
        [B('⬅ Настройки', callback_data='up:settings')],
    ])


async def show_update_menu(update):
    q = update.callback_query
    msg = q.message if q else update.message
    await msg.reply_text(
        f'🔄 Центр обновлений · v{VERSION}\n\n'
        'Здесь можно сохранить резервную копию, проверить релизы '
        'и установить проверенный тобой ZIP без ручной замены .py файлов.\n\n'
        'Установка меняет код на диске. Для включения новой версии '
        'нужно перезапустить бота. SQLite и ключи не заменяются.',
        reply_markup=update_keyboard())


async def handle_update_callback(update, context):
    import bot
    q = update.callback_query
    await q.answer()
    action = q.data or ''
    uid = update.effective_user.id
    if bot.OWNER_ID is None or uid != bot.OWNER_ID:
        await q.message.reply_text('🔒 Доступ только владельцу.');return
    if action == 'up:settings':
        from focus_ui import show_menu
        await show_menu(update, 'settings');return
    if action == 'up:status':
        with bot.connect() as db:
            state = release_settings(db, uid)
        try:
            url = configured_manifest_url()
            source = ('подключён' if url else 'не настроен')
        except UpdateError:
            source = 'неверный адрес в настройках'
        await q.message.reply_text(
            f'📦 Установленная версия: {VERSION}\n'
            f'Ежедневная проверка: {"включена" if state["enabled"] else "выключена"}\n'
            f'Источник релизов: {source}\n'
            f'Последняя проверка: {state["last_check_date"] or "ещё не было"}\n'
            'Установка: только после двух подтверждений владельца.\n'
            'После установки требуется перезапуск процесса.',
            reply_markup=update_keyboard())
        return
    if action in ('up:auto_on', 'up:auto_off'):
        with bot.connect() as db:
            release_set_enabled(db, uid, action == 'up:auto_on')
        await q.message.reply_text('✅ Ежедневная проверка включена. Проверь подключение release.json через «Версия и состояние». '
                                   if action == 'up:auto_on' else '🔕 Ежедневная проверка выключена.',
                                   reply_markup=update_keyboard())
        return
    if action == 'up:check':
        await _manual_check(q.message)
        return
    if action == 'up:fetch':
        await _download_published_zip(q.message, context)
        return
    if action == 'up:backup':
        try:
            archive_dir = snapshot(Path(bot.__file__).resolve().parent, bot.DB_PATH, label='from_telegram')
        except Exception as exc:
            await q.message.reply_text('⚠️ Резервную копию создать не удалось: '+type(exc).__name__);return
        await q.message.reply_text(
            '✅ Создана локальная резервная копия Python-файлов и SQLite.\n'
            f'Папка: backups/{archive_dir.name}\n'
            'Она находится на том же компьютере/сервере; для защиты от поломки диска '
            'дополнительно сохрани копию на другом устройстве.',reply_markup=update_keyboard())
        return
    if action == 'up:upload':
        context.user_data.pop('pending_zip',None)
        context.user_data['expect_update_zip']=True
        await q.message.reply_text(
            '📦 Пришли ZIP-архив обновления обычным файлом Telegram (документом).\n'
            'Максимальный размер: 4 МБ. Устанавливай только архивы из доверенного источника.\n'
            'Я сначала покажу список файлов и контрольную сумму. '
            'Без твоего подтверждения ничего не поменяется.\n'
            'Для отмены напиши «отмена».')
        return
    if action == 'up:cancel':
        context.user_data.pop('pending_zip',None)
        context.user_data.pop('expect_update_zip',None)
        await q.message.reply_text('✅ Установка отменена.');return
    if action.startswith('up:apply:'):
        pending=context.user_data.get('pending_zip')
        token=action[len('up:apply:'):]
        if (not pending or time.monotonic()-pending['created']>900 or
            pending['digest'][:16]!=token):
            await q.message.reply_text('⚠️ Подтверждение устарело. Загрузить ZIP нужно заново.');return
        # One-time authorization; stale duplicated Telegram callback cannot reapply.
        context.user_data.pop('pending_zip',None)
        try:
            files, backup=apply_update(Path(bot.__file__).resolve().parent, bot.DB_PATH,
                pending['content'], expected_sha256=pending['digest'])
        except Exception as exc:
            await q.message.reply_text(
                '❌ Обновление не применено. Причина: '+str(exc)[:500]+
                '\nДействующая база данных не изменена.')
            return
        await q.message.reply_text(
            f'✅ Файлы обновлены ({len(files)} шт.).\n'
            f'Резервная копия: backups/{backup.name}\n\n'
            '⚠️ Текущий бот пока работает на старом коде. '
            'На Windows: останови его в CMD через Ctrl+C, затем выполни python bot.py.\n'
            'На облачном сервере перезапусти службу бота.\n'
            'После запуска открой «Версия и состояние».')


async def handle_update_document(update, context):
    """Only owner document uploads when explicitly requested by the menu."""
    import bot
    message=update.message
    doc=message.document
    uid=update.effective_user.id
    if bot.OWNER_ID is None or uid != bot.OWNER_ID:
        return
    if not context.user_data.get('expect_update_zip'):
        await message.reply_text('Чтобы установить обновление, открой ⚙️ Настройки → 🔄 Обновления.')
        return
    if not doc.file_name or not doc.file_name.lower().endswith('.zip'):
        await message.reply_text('Нужен файл с расширением .zip. Попробуй снова.');return
    if doc.file_size and doc.file_size>MAX_ARCHIVE_BYTES:
        await message.reply_text('ZIP слишком большой. Максимум 4 МБ.');return
    try:
        remote=await doc.get_file()
        content=bytes(await remote.download_as_bytearray())
        filenames=inspect_zip(content)
    except (UpdateError, ValueError) as exc:
        await message.reply_text('⚠️ ZIP отклонён: '+str(exc)[:400]);return
    except Exception as exc:
        await message.reply_text('⚠️ Не удалось загрузить ZIP: '+type(exc).__name__);return
    await _present_zip(message, context, content, filenames)


async def _present_zip(message, context, content, filenames=None, version=None):
    if filenames is None:
        filenames = inspect_zip(content)
    signature = digest(content)
    context.user_data.pop('expect_update_zip', None)
    context.user_data['pending_zip'] = {
        'content': content, 'digest': signature, 'created': time.monotonic()}
    heading = f'📦 Версия {version}\n' if version else ''
    await message.reply_text(
        '🔍 Предпросмотр обновления:\n' + heading +
        ''.join('• ' + name + '\n' for name in filenames) +
        f'\nSHA-256: {signature}\n\n'
        '⚠️ Это исполняемый Python-код. Хеш защищает от случайной подмены файла, '
        'но не делает неизвестного издателя безопасным. '
        'SQLite и токены не заменяются. Неизвестные зависимости не устанавливаются.\n'
        'Подтверди установку ТОЛЬКО если доверяешь источнику.',
        reply_markup=M([
            [B('✅ Подтвердить установку',callback_data='up:apply:'+signature[:16])],
            [B('❌ Отмена',callback_data='up:cancel')],
        ]))


def _offer_keyboard():
    return M([
        [B('📥 Получить и проверить ZIP',callback_data='up:fetch')],
        [B('📦 Загрузить свой ZIP',callback_data='up:upload')],
        [B('❌ Отмена',callback_data='up:cancel')],
    ])


async def _manual_check(message):
    import bot
    try:
        url = configured_manifest_url()
    except UpdateError as exc:
        await message.reply_text('⚠️ '+str(exc)); return
    if not url:
        await message.reply_text(
            '🔎 Ежедневная проверка ещё не подключена: отсутствует '
            'ASSISTANT_UPDATE_MANIFEST_URL.\n'
            'Нужен доверенный HTTPS-адрес файла release.json. '
            'Как его настроить — см. README_V204.txt.\n'
            'Пока обновления можно загружать вручную через Telegram.',
            reply_markup=update_keyboard())
        return
    try:
        release=await asyncio.to_thread(fetch_release,url)
    except Exception as exc:
        await message.reply_text('⚠️ Не удалось проверить релизы: '+str(exc)[:350]);return
    with bot.connect() as db:
        release_mark_checked(db,bot.OWNER_ID,bot.now().date().isoformat())
    if not release_is_newer(release):
        await message.reply_text(f'✅ Установлена v{VERSION}. Новее проверенного релиза '
                                 f'v{release["version"]} ничего нет.')
    else:
        await message.reply_text(
            f'🆕 Доступна v{release["version"]} (сейчас v{VERSION}).\n'
            f'Изменения: {release["notes"] or "не указаны"}\n\n'
            'Нажми «Получить и проверить ZIP», затем отдельно подтверди установку.',
            reply_markup=_offer_keyboard())


async def _download_published_zip(message, context):
    try:
        url=configured_manifest_url()
        if not url:
            raise UpdateError('Сначала настрой ASSISTANT_UPDATE_MANIFEST_URL.')
        release=await asyncio.to_thread(fetch_release,url)
        if not release_is_newer(release):
            await message.reply_text('Более новой версии не обнаружено.');return
        content=await asyncio.to_thread(fetch_release_zip,release,url)
    except Exception as exc:
        await message.reply_text('❌ Не удалось подготовить релиз: '+str(exc)[:400]);return
    await _present_zip(message,context,content,version=release['version'])


async def scheduled_release_check(context):
    """Once per local calendar day, outside quiet hours; no unapproved install."""
    import bot
    owner = bot.OWNER_ID
    if owner is None:
        return
    current=bot.now()
    if not (8 <= current.hour < 23):
        return
    try:
        url = configured_manifest_url()
        if not url:
            return
    except UpdateError:
        return
    local_date=current.date().isoformat()
    with bot.connect() as db:
        state=release_settings(db,owner)
        if not state['enabled'] or state['last_check_date']==local_date:
            return
        # Reserve the daily attempt before network I/O (avoids duplicates).
        release_mark_checked(db,owner,local_date)
    try:
        release=await asyncio.to_thread(fetch_release,url)
    except Exception as exc:
        # No unsolicited error flood: owner can check manually.
        print('Проверка релизов не удалась:',type(exc).__name__)
        return
    if not release_is_newer(release):
        return
    with bot.connect() as db:
        state=release_settings(db,owner)
        if state['notified_version']==release['version']:
            return
    try:
        await context.bot.send_message(
            chat_id=owner,
            text=f'🆕 Доступен Personal AI Assistant v{release["version"]}!\n'
                 f'Сейчас v{VERSION}.\n'
                 f'Изменения: {release["notes"] or "не указаны"}\n\n'
                 'Обновление не скачано и не установлено. '
                 'Нажми кнопку, чтобы проверить архив, затем отдельно подтверди установку.',
            reply_markup=_offer_keyboard())
    except Exception as exc:
        print('Не удалось сообщить о новом релизе:',type(exc).__name__)
        return
    with bot.connect() as db:
        release_mark_notified(db,owner,release['version'])
